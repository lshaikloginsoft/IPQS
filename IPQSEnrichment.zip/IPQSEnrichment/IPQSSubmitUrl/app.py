"""
Main Function
"""

# pylint: disable=logging-fstring-interpolation
import logging
import traceback
from json import dumps

import azure.functions as func

from .api import IPQS


def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    This function handles IPQS API and returns HTTP response
    :param req: func.HttpRequest
    """
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        logging.info("Attempting to extract request parameters...")
        url = req.params.get("url") or req.get_json().get("url")

        if not url:
            logging.warning("Request missing 'url' parameter.")
            return func.HttpResponse(
                "Invalid Request. Missing 'url' parameter.", status_code=400
            )
        ipqs = IPQS(logging)
        params = {'url':url}
        endpoint = "/malware/scan/"

        logging.info(f"Sending request to IPQS endpoint: {endpoint}")
        response = ipqs.request_ipqs_api("POST", endpoint, params)

        response.pop("update_url", None)

        logging.info("Successfully received response from IPQS.")
        return func.HttpResponse(
            dumps(response),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )
    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        error_detail = traceback.format_exc()
        logging.error(
            f"Exception Occurred: {str(ex)}, Traceback {error_detail}"
        )
        return func.HttpResponse("Internal Server Exception", status_code=500)
