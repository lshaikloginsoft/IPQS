"""
Main Function
"""

# pylint: disable=logging-fstring-interpolation

import base64
import logging
import traceback
from io import BytesIO
from json import dumps

import azure.functions as func

from ipqs_api import IPQS


def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    This function handles IPQS API and returns HTTP response
    :param req: func.HttpRequest
    """
    logging.info(f"Resource Requested: {func.HttpRequest}")

    try:
        logging.info("Attempting to extract request parameters...")
        file = req.params.get("file") or req.get_json().get("file")
        name = req.params.get("name") or req.get_json().get("name")

        if not file:
            logging.warning("Request missing 'file' parameter.")
            return func.HttpResponse(
                "Invalid Request. Missing 'file' parameter.", status_code=400
            )
        ipqs = IPQS(logging)
        binary_data = base64.b64decode(file)
        file_object = BytesIO(binary_data)
        file_object.name = name
        endpoint = "/malware/lookup"
        files = {"file": file_object}

        logging.info(f"Sending request to IPQS endpoint: {endpoint}")
        response = ipqs.request_ipqs_api("POST", endpoint, files=files)

        response.pop("update_url", None)

        logging.info("Successfully received response from IPQS.")
        return func.HttpResponse(
            dumps(response),
            headers={"Content-Type": "application/json"},
            status_code=200,
        )

    except KeyError as ke:
        logging.error(f"Invalid Settings. {ke.args} configuration is missing.")
        return func.HttpResponse(
            "Invalid Settings. Configuration is missing.", status_code=500
        )
    except Exception as ex:
        error_detail = traceback.format_exc()
        logging.error(
            f"Exception Occurred: {str(ex)}, Traceback {error_detail}"
        )
        return func.HttpResponse("Internal Server Exception", status_code=500)
